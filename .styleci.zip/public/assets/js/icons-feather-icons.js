$(function() {
	"use strict";

    feather.replace()


});